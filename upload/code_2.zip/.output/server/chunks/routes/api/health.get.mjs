import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const health_get = defineEventHandler(() => ({ ok: true, service: "courtlink", integrations: { neon: !!process.env.DATABASE_URL, neonAuth: !!process.env.NEON_AUTH_BASE_URL, cloudinary: !!process.env.CLOUDINARY_CLOUD_NAME }, timestamp: (/* @__PURE__ */ new Date()).toISOString() }));

export { health_get as default };
//# sourceMappingURL=health.get.mjs.map
