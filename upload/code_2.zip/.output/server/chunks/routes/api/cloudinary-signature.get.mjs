import { d as defineEventHandler, g as getQuery, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import nodeCrypto from 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';

const cloudinarySignature_get = defineEventHandler((event) => {
  const config = useRuntimeConfig();
  const query = getQuery(event);
  const timestamp = String(query.timestamp || Math.floor(Date.now() / 1e3));
  const folder = "courtlink";
  const signature = nodeCrypto.createHash("sha1").update(`folder=${folder}&timestamp=${timestamp}${config.cloudinaryApiSecret || ""}`).digest("hex");
  return { cloudName: config.public.cloudinaryCloudName, apiKey: config.cloudinaryApiKey || null, timestamp, folder, signature };
});

export { cloudinarySignature_get as default };
//# sourceMappingURL=cloudinary-signature.get.mjs.map
