import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import { neon } from '@neondatabase/serverless';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const neonStatus_get = defineEventHandler(async () => {
  var _a;
  const url = process.env.DATABASE_URL;
  if (!url) return { configured: false, connected: false, mode: "demo-localStorage" };
  try {
    const sql = neon(url);
    const rows = await sql`select 1 as connected`;
    return { configured: true, connected: ((_a = rows[0]) == null ? void 0 : _a.connected) === 1, mode: "neon-postgres" };
  } catch {
    return { configured: true, connected: false, mode: "neon-postgres", error: "Connexion indisponible" };
  }
});

export { neonStatus_get as default };
//# sourceMappingURL=neon-status.get.mjs.map
