import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const authConfig_get = defineEventHandler(() => ({ provider: "neon-managed-better-auth", configured: Boolean(process.env.NEON_AUTH_BASE_URL && process.env.NEON_AUTH_COOKIE_SECRET), baseUrlPresent: Boolean(process.env.NEON_AUTH_BASE_URL), cookieSecretPresent: Boolean(process.env.NEON_AUTH_COOKIE_SECRET), note: "Les secrets ne sont jamais renvoy\xE9s par cette route." }));

export { authConfig_get as default };
//# sourceMappingURL=auth-config.get.mjs.map
