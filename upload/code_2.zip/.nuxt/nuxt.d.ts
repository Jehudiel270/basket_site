/// <reference types="@nuxtjs/tailwindcss" />
/// <reference types="@nuxt/telemetry" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/builder-env.d.ts" />
/// <reference types="nuxt" />
/// <reference path="types/app-defaults.d.ts" />
/// <reference path="types/plugins.d.ts" />
/// <reference path="types/build.d.ts" />
/// <reference path="types/schema.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference path="../node_modules/.pnpm/@nuxt+vite-builder@3.21.11_@types+node@22.20.5_magicast@0.5.5_nuxt@3.21.11_@oxc-project_42429bb9eca7ddb9014dfbdded82452b/node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../node_modules/.pnpm/@nuxt+nitro-server@3.21.11_db0@0.3.4_esbuild@0.28.2_ioredis@5.11.1_magicast@0.5.5_nuxt@_0b0d96d9d000b2135e1ecb85dfff1f3f/node_modules/@nuxt/nitro-server/dist/index.d.mts" />
/// <reference path="types/layouts.d.ts" />
/// <reference types="vue-router" />
/// <reference path="types/middleware.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="types/components.d.ts" />
/// <reference path="imports.d.ts" />
/// <reference path="types/imports.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />
/// <reference path="types/nitro.d.ts" />

export {}
